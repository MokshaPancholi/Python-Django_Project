from django.db import models

# Create your models here.
class Car(models.Model):
    Make = models.CharField(choices=[("honda","Honda"),("toyota","Toyota"),("nissan","Nissan"),("ford","Ford")])
    Fuel_Type = models.CharField(choices=[("gasoline","Gasoline"),("hybrid","Hybrid"),("electric","Electric"),("diesel","Diesel"),("naturalgas","Natural Gas")])
    Model = models.CharField()
    Year = models.DateField()
    Price = models.IntegerField()
    Available = models.BooleanField(default=False)
    Image = models.URLField(null=True,blank=True)
    Description = models.TextField()

class Store(models.Model):
    Name = models.CharField(max_length=30)
    Address = models.CharField()
    Phone = models.CharField(max_length=10)
    Number = models.IntegerField()
    Email = models.EmailField()
    OpenTimings = models.TimeField()
    Website = models.URLField()

class Purchase(models.Model):
    CustomerName = models.CharField()
    CarMake = models.CharField(choices=[("honda","Honda"),("toyota","Toyota"),("nissan","Nissan"),("ford","Ford")])
    CarModel = models.CharField(max_length=100)
    Store = models.CharField(choices=[("ahmedabad","Ahmedabad"),("baroda","Baroda"),("surat","Surat"),("rajkot","Rajkot")])
    PurchaseDate = models.DateTimeField(auto_now_add=True)
    PricePaid = models.IntegerField()
    PaymentMethod = models.CharField()
    time_stamp = models.DateTimeField(auto_now=True)

