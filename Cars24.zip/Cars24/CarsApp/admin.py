from django.contrib import admin
from CarsApp.models import *
# Register your models here.

@admin.register(Car)
class Car(admin.ModelAdmin):
    list_display1 = ["Make", "Fuel_Type", "Model", "Year", "Price", "Available", "Image", "Description"]

@admin.register(Store)
class Store(admin.ModelAdmin):
    list_display2 = ["Name", "Address", "Phone Number", "Email", "OpenTimings", "Website"]

@admin.register(Purchase)
class Purchase(admin.ModelAdmin):
    list_display3 = ["Customer Name", "Car Make", "Car Model", "Store", "Purchase Date", "Price Paid", "Payment Method",
                     "time_stamp"]